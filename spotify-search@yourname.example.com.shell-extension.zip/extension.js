// src/extension.ts
import Gio from "gi://Gio";
import GLib from "gi://GLib";
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
var SpotifySearchProvider = class {
  id = "spotify-search-provider";
  appInfo;
  canModifyContentList = false;
  constructor() {
    this.appInfo = Gio.DesktopAppInfo.new("spotify.desktop") || Gio.DesktopAppInfo.new("com.spotify.Client.desktop");
  }
  getInitialResultSet(terms, cancellable) {
    return new Promise((resolve) => {
      const query = terms.join(" ");
      if (query.toLowerCase().includes("spotify")) {
        resolve(["spotify:track:placeholder"]);
      } else {
        resolve([]);
      }
    });
  }
  getSubsearchResultSet(previousResults, terms, cancellable) {
    return this.getInitialResultSet(terms, cancellable);
  }
  getResultMetas(resultIds, cancellable) {
    return new Promise((resolve) => {
      const metas = resultIds.map((id) => ({
        id,
        name: "Spotify Search Result",
        description: "Click to play in Spotify",
        createIcon: (size) => {
          if (this.appInfo) return this.appInfo.create_icon_texture(size);
          return null;
        }
      }));
      resolve(metas);
    });
  }
  filterResults(results, max) {
    return results.slice(0, max);
  }
  activateResult(id, terms) {
    const bus = Gio.DBus.session;
    bus.call(
      "org.mpris.MediaPlayer2.spotify",
      "/org/mpris/MediaPlayer2",
      "org.mpris.MediaPlayer2.Player",
      "OpenUri",
      new GLib.Variant("(s)", [id]),
      null,
      Gio.DBusCallFlags.NONE,
      -1,
      null,
      null
    );
  }
};
var SpotifySearchExtension = class extends Extension {
  provider = null;
  enable() {
    this.provider = new SpotifySearchProvider();
    Main.overview.searchController.addProvider(this.provider);
  }
  disable() {
    if (this.provider) {
      Main.overview.searchController.removeProvider(this.provider);
      this.provider = null;
    }
  }
};
export {
  SpotifySearchExtension as default
};
