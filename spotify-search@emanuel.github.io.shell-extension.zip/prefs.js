// src/prefs.ts
import Adw from "gi://Adw";
import Gio from "gi://Gio";
import Gtk from "gi://Gtk?version=4.0";
import GLib from "gi://GLib";
import Soup from "gi://Soup?version=3.0";
import { ExtensionPreferences } from "resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js";

// src/spotify-config.ts
var BUNDLED_SPOTIFY_CLIENT_ID = "b7c53c9dc6824f13b36049065ae2f12f";

// src/prefs.ts
function effectiveClientId(settings) {
  const s = settings.get_string("client-id").trim();
  return s || BUNDLED_SPOTIFY_CLIENT_ID;
}
var SPOTIFY_SCOPES = "user-modify-playback-state user-library-read";
function addSettingsRow(group, settings, key, title, options) {
  const row = new Adw.ActionRow({ title });
  const entry = new Gtk.Entry({
    valign: Gtk.Align.CENTER,
    width_request: 260,
    hexpand: true
  });
  if (options.password) {
    entry.visibility = false;
    entry.input_purpose = Gtk.InputPurpose.PASSWORD;
  }
  settings.bind(key, entry, "text", Gio.SettingsBindFlags.DEFAULT);
  row.add_suffix(entry);
  group.add(row);
  return entry;
}
var DEFAULT_REDIRECT_URI = "http://127.0.0.1:8080";
function getOAuthRedirectUri(settings) {
  const s = settings.get_string("oauth-redirect-uri").trim();
  return s || DEFAULT_REDIRECT_URI;
}
function getOAuthRedirectPort(redirectUri) {
  try {
    const u = GLib.Uri.parse(redirectUri, GLib.UriFlags.NONE);
    const p = u.get_port();
    if (p > 0) return p;
    return 8080;
  } catch {
    return 8080;
  }
}
function randomPkceVerifier(length) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
  let s = "";
  for (let i = 0; i < length; i++) {
    s += chars[Math.floor(Math.random() * chars.length)];
  }
  return s;
}
var SpotifyPrefs = class extends ExtensionPreferences {
  fillPreferencesWindow(window) {
    const page = new Adw.PreferencesPage();
    const credsGroup = new Adw.PreferencesGroup({
      title: "Spotify connection",
      description: "Search uses a bundled Spotify app (PKCE). In the Developer Dashboard for that app, add a Redirect URI that matches the field below exactly. HTTP only on your machine\u2014use http://127.0.0.1:PORT or http://localhost:PORT, not https."
    });
    page.add(credsGroup);
    window.add(page);
    const settings = this.getSettings();
    for (const key of ["oauth-redirect-uri", "refresh-token", "client-id", "client-secret"]) {
      if (!settings.is_writable(key)) {
        console.error(`[spotify-search prefs] gsettings key not writable: ${key}`);
      }
    }
    const redirectEntry = addSettingsRow(
      credsGroup,
      settings,
      "oauth-redirect-uri",
      "Redirect URI (must match Spotify app)",
      {}
    );
    window.connect("close-request", () => {
      settings.set_string("oauth-redirect-uri", redirectEntry.get_text().trim());
      settings.apply();
      return false;
    });
    const authGroup = new Adw.PreferencesGroup({
      title: "Spotify account",
      description: "Log in for $queue and liked songs first on $play. Re-login after upgrading (new permissions). The browser opens Spotify; the callback URL is your Redirect URI above."
    });
    page.add(authGroup);
    const authRow = new Adw.ActionRow({ title: "Log in with Spotify" });
    const btn = new Gtk.Button({
      label: "Log In",
      valign: Gtk.Align.CENTER,
      css_classes: ["suggested-action"]
    });
    authRow.add_suffix(btn);
    authGroup.add(authRow);
    btn.connect("clicked", () => {
      const clientId = effectiveClientId(settings);
      const clientSecret = settings.get_string("client-secret").trim();
      const redirectUri = getOAuthRedirectUri(settings);
      const port = getOAuthRedirectPort(redirectUri);
      const lower = redirectUri.toLowerCase();
      if (lower.startsWith("https:")) {
        btn.set_label("Redirect URI cannot be https (local server is HTTP only)");
        return;
      }
      if (!lower.startsWith("http:")) {
        btn.set_label("Redirect URI must start with http://");
        return;
      }
      const usePkce = !clientSecret;
      const pkceVerifier = usePkce ? randomPkceVerifier(64) : "";
      btn.set_label("Waiting for browser\u2026");
      const server = new Soup.Server({});
      server.add_handler("/", (srv, msg, _path, _query) => {
        const uri = msg.get_uri();
        const queryStr = uri.get_query();
        if (queryStr && queryStr.includes("error=")) {
          const errMatch = queryStr.match(/error=([^&]*)/);
          const descMatch = queryStr.match(/error_description=([^&]*)/);
          const errCode = errMatch ? decodeURIComponent(errMatch[1].replace(/\+/g, " ")) : "error";
          const errDesc = descMatch ? decodeURIComponent(descMatch[1].replace(/\+/g, " ")) : errCode;
          btn.set_label(`Spotify: ${errDesc.substring(0, 80)}`);
        }
        if (queryStr && queryStr.includes("code=")) {
          const raw = queryStr.split("code=")[1]?.split("&")[0] ?? "";
          let code;
          try {
            code = decodeURIComponent(raw.replace(/\+/g, "%20"));
          } catch {
            code = raw;
          }
          btn.set_label("Exchanging code\u2026");
          const reqMsg = Soup.Message.new("POST", "https://accounts.spotify.com/api/token");
          reqMsg.request_headers.append("Content-Type", "application/x-www-form-urlencoded");
          let body;
          if (usePkce) {
            body = `grant_type=authorization_code&code=${encodeURIComponent(code)}&redirect_uri=${encodeURIComponent(redirectUri)}&client_id=${encodeURIComponent(clientId)}&code_verifier=${encodeURIComponent(pkceVerifier)}`;
          } else {
            const authBytes = new TextEncoder().encode(`${clientId}:${clientSecret}`);
            const authB64 = GLib.base64_encode(authBytes);
            reqMsg.request_headers.append("Authorization", `Basic ${authB64}`);
            body = `grant_type=authorization_code&code=${encodeURIComponent(code)}&redirect_uri=${encodeURIComponent(redirectUri)}`;
          }
          reqMsg.set_request_body_from_bytes(
            "application/x-www-form-urlencoded",
            // @ts-ignore
            GLib.Bytes.new(new TextEncoder().encode(body))
          );
          const session = new Soup.Session();
          session.send_and_read_async(reqMsg, GLib.PRIORITY_DEFAULT, null, (s, res) => {
            try {
              const bytes = s.send_and_read_finish(res);
              const dataArray = bytes.get_data();
              if (!dataArray) {
                btn.set_label("Empty token response");
                return;
              }
              const text = new TextDecoder("utf-8").decode(dataArray);
              const data = JSON.parse(text);
              if (data.error) {
                const detail = data.error_description || data.error;
                btn.set_label(`Spotify: ${detail.substring(0, 80)}`);
                return;
              }
              if (data.refresh_token) {
                settings.set_string("refresh-token", data.refresh_token);
              }
              if (settings.get_string("refresh-token")) {
                settings.apply();
                btn.set_label("Saved. $queue and liked-first search work.");
                return;
              }
              btn.set_label(
                "No refresh token \u2014 in Spotify account remove app access once, then log in again"
              );
            } catch (e) {
              btn.set_label("Error exchanging code");
            }
          });
        }
        msg.get_response_headers().set_content_type("text/html", null);
        const html = '<div style="font-family: sans-serif; text-align: center; padding-top: 100px;"><h1 style="color: #1DB954;">Authorized</h1><p>You can close this tab and return to extension settings.</p></div>';
        msg.get_response_body().append(html);
        msg.set_status(200, null);
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2e3, () => {
          server.disconnect();
          return GLib.SOURCE_REMOVE;
        });
      });
      try {
        server.listen_local(port, Soup.ServerListenOptions.IPV4_ONLY);
      } catch {
        btn.set_label(`Port ${port} busy \u2014 change Redirect URI port or free it`);
        return;
      }
      const scope = encodeURIComponent(SPOTIFY_SCOPES);
      let authUrl = `https://accounts.spotify.com/authorize?client_id=${encodeURIComponent(clientId)}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&prompt=consent`;
      if (usePkce) {
        authUrl += `&code_challenge_method=plain&code_challenge=${encodeURIComponent(pkceVerifier)}`;
      }
      Gio.AppInfo.launch_default_for_uri(authUrl, null);
    });
  }
};
export {
  SpotifyPrefs as default
};
